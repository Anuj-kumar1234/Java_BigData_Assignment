public class Solution2 {
    public static int count(int[] list, int num1, int num2) {
        int start = 0;
        int end = list.length - 1;
        int count = 0;

        while (start <= end) {
            int mid = start + (end - start) / 2;
            if (list[mid] >= num1 && list[mid] <= num2) {
                count++;
                int i = mid - 1;
                while (i >= 0 && list[i] >= num1) {
                    count++;
                    i--;
                }
                i = mid + 1;
                while (i < list.length && list[i] <= num2) {
                    count++;
                    i++;
                }
                break;
            } else if (list[mid] < num1) {
                start = mid + 1;
            } else {
                end = mid - 1;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        int[] list = {0, 1, 5, 8, 14, 18, 44, 81, 89, 99, 102};
        int num1 = 10;
        int num2 = 20;

        System.out.println(count(list, num1, num2));
    }
}
